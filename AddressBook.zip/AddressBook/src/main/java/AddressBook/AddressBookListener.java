package AddressBook;

public interface AddressBookListener {

    public void handleAddressBookEvent(AddressBookEvent e);
}
