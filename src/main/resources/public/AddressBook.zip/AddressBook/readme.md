A Java project to learn Spring+Thymeleaf+H2+JPA

## Lab 5 Info: 
- Run the application using spring-boot
- navigate to <a href="localhost:8080/index.html">localhost:8080/index.html</a> for the SPA version of the application
- there are also controllers for running the application without javascript, using just Thymeleaf templates. 
  - To use the application like this, navigate to <a href="localhost:8080/addressbooks">localhost:8080/addressbooks</a>
  